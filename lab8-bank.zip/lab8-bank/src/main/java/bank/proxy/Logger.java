package bank.proxy;

public class Logger {
    public static void log(String message){
        System.out.println("The logged message is "+message);
    }
}
