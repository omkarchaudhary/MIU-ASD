package product.customers;

public interface ILogger {
    void log (String logstring);
}
