package counter;

public  interface Observer {
    void update(int count);
}
