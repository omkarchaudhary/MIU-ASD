package bank.domain;

public enum AccountType {
    SAVINGACCOUNT,
    CHECKINGACCOUNT
}
