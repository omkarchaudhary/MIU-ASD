package game;

public interface GameState {
     void addPoints(int newPoints);
}
