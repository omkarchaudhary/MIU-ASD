package application;

import framework.FWContext;

public class Application {

	public static void main(String[] args) {
		FWContext fWContext = new FWContext();
		fWContext.start();
	}

}
