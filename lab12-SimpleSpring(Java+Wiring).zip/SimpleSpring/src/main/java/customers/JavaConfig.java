package customers;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JavaConfig {
    @Bean
    public IEmailSender emailSender(){
        return new EmailSender();
    }

    public ILogger logger(){
        return new Logger();
    }

    public CustomerDAO customerDAO(){
        ILogger logger = logger();
        return new CustomerDAO(logger);
    }
    @Bean
    public CustomerService customerService(){
        ICustomerDAO customerDAO = customerDAO();
        IEmailSender emailSender = emailSender();
        CustomerService customerService = new CustomerService();
        customerService.setCustomerDAO(customerDAO,emailSender);
        return customerService;
    }
}
