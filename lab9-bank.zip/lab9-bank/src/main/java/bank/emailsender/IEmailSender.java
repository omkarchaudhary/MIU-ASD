package bank.emailsender;

public interface IEmailSender {
    void sendEmail(String reason);
}
