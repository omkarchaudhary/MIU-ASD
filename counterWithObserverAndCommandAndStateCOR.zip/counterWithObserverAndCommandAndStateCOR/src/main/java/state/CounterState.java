package state;

public interface CounterState {
    void increment();
    void decrement();
}
