package cor;

public interface ColorHandler {
    void handler(int count);
    void setHandler(ColorHandler colorHandler);
}
