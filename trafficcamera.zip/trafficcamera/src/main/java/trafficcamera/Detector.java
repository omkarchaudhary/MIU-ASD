package trafficcamera;

public interface Detector {
    void detect(Camera camera);
    void setDetector(Detector detector);
}
